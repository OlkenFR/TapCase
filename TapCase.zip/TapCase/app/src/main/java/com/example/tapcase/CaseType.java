package com.example.tapcase;

public enum CaseType {
    ClassicCase,
    DreamsCase,
    BravoCase,
    CobbleCase
}
